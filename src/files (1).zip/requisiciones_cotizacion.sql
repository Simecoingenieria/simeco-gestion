-- ============================================================
-- Tabla: requisiciones_cotizacion
-- Proceso: B. Gestión Gerencial y Comercial (FO.GGC.02)
-- Es el insumo de entrada que el Cotizador lee para precargar
-- materiales, mano de obra y herramientas.
-- ============================================================

create table if not exists requisiciones_cotizacion (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  -- Consecutivo visible al usuario (igual al de tus RQ en Drive: "294 - RQ ...")
  consecutivo text,

  -- Datos generales (FO.GGC.02)
  cliente text not null,
  sede text,
  fecha_solicitud date,
  fecha_limite date,
  solicitante_nombre text,
  solicitante_cargo text,
  solicitante_telefono text,
  solicitante_correo text,
  proyecto text,          -- campo libre
  servicio text,          -- campo libre
  palabra_clave text,

  -- Listas como JSON: cada una es un array de objetos
  -- materiales / herramientas: [{ descripcion, cantidad, unidad, observaciones }]
  -- mano_obra:                 [{ descripcion, cantidad, unidad, observaciones }]
  -- recurso_humano:            [{ descripcion, cantidad, dias, observaciones }]
  materiales jsonb not null default '[]'::jsonb,
  mano_obra jsonb not null default '[]'::jsonb,
  recurso_humano jsonb not null default '[]'::jsonb,
  herramientas jsonb not null default '[]'::jsonb,

  -- URLs de Supabase Storage (no los blobs en sí)
  fotos_urls jsonb not null default '[]'::jsonb,

  -- Ciclo de vida de la RQ
  -- borrador -> enviada_a_cotizador -> cotizada
  estado text not null default 'borrador'
    check (estado in ('borrador', 'enviada_a_cotizador', 'cotizada')),

  -- Enlace hacia la cotización generada a partir de esta RQ.
  -- NOTA: sin "references cotizaciones(id)" por ahora, porque esa tabla
  -- todavía no existe en tu proyecto (recién creado). Cuando migres el
  -- Cotizador a Supabase y crees esa tabla, se puede agregar la relación
  -- formal con: alter table requisiciones_cotizacion
  --   add constraint fk_cotizacion foreign key (cotizacion_id) references cotizaciones(id);
  cotizacion_id uuid,

  -- Quién la creó. Queda en null mientras no tengas login configurado
  -- (login individual vs. compartido es una decisión aún pendiente).
  creado_por uuid
);

create index if not exists idx_requisiciones_estado on requisiciones_cotizacion(estado);
create index if not exists idx_requisiciones_cliente on requisiciones_cotizacion(cliente);
create index if not exists idx_requisiciones_cotizacion_id on requisiciones_cotizacion(cotizacion_id);

-- Mantiene updated_at al día en cada edición
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_requisiciones_updated_at on requisiciones_cotizacion;
create trigger trg_requisiciones_updated_at
  before update on requisiciones_cotizacion
  for each row execute function set_updated_at();

-- ============================================================
-- RLS: versión PROVISIONAL para poder probar ya mismo, sin login
-- configurado todavía. Permite leer/escribir a cualquiera que tenga
-- la publishable key (que es pública por diseño).
--
-- ⚠️ IMPORTANTE: esto es temporal. Una vez definas si el login es
-- individual o compartido, hay que reemplazar estas políticas por
-- unas que solo permitan acceso a usuarios autenticados de verdad
-- (auth.role() = 'authenticated'), o restrinjan por creado_por.
-- Sin eso, cualquier persona con la publishable key (que es visible
-- en el código del navegador) podría leer y escribir en esta tabla.
-- ============================================================

alter table requisiciones_cotizacion enable row level security;

create policy "Acceso temporal sin autenticación (ajustar luego)"
  on requisiciones_cotizacion for all
  using (true)
  with check (true);
